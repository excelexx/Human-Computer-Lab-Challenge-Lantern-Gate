"""Deterministic quest choices: explicit player consent, never model-issued actions."""
import html
import re

from .scene import SAMPLE_LINES

ROUTE_LINES = (
    "Fine. The bridge it is.", "The sea stairs, then.",
    "That bridge sounds inviting.", "Those stairs sound delightful.",
)
READY_LINES = (
    "Lead the way.", "Let's do this.",
    "Ready as I'll ever be.", "Actually, let's stay here.",
)
ALL_EXAMPLES = SAMPLE_LINES + ROUTE_LINES + READY_LINES


def initial_quest():
    return {"completed": 0, "route": None, "phase": "talking"}


def options(quest):
    if quest["completed"] == 0:
        return SAMPLE_LINES
    if quest.get("route") is None:
        return ROUTE_LINES
    return READY_LINES


def _words(text):
    return re.sub(r"\s+", " ", text.casefold().translate(str.maketrans({"’": "'", "‘": "'", "“": '"', "”": '"', "—": ";", "–": ";"}))).strip()


def player_intent(text):
    """Conservative authored command grammar, independent of estimated emotion.

    This is intentionally not a general language understanding model. Questions,
    reported speech and conditional plans never grant movement permission.
    Selecting a preference alone is also separate from agreeing to leave now.
    """
    words = _words(text)
    # Quoted commands describe words, not the player's consent. Apostrophes in
    # contractions are retained; double-quoted spans are excluded from actions.
    actions = re.sub(r'"[^"\n]*"', "", words)
    actions = re.sub(r"\b(?:don't|do not) worry\b", "", actions)
    clauses = [re.sub(r"^(?:(?:okay|ok|well|actually|fine|yes|then|please|so)\s+)+", "", part.strip())
               for part in re.split(r"[.!?;,\n]|\b(?:but|and)\b", actions) if part.strip()]
    question = "?" in words or bool(re.match(r"^(?:i (?:want|need|would like) to (?:know|understand)|tell me|explain|describe|what|why|how|who|where|when|which|are you|do you|does|can (?:you|we|i)|could|should|would)\b", words))
    switch_route = bool(re.fullmatch(r"(?:let's|lets|please|i want to) (?:choose|take|try|switch to) the other route[.!]*", words))
    uncertain = bool(re.search(r"\b(?:if|unless|maybe|perhaps|might|could|suppose|hypothetically|not sure|changed my mind|other route)\b", actions))
    deferred = bool(re.search(r"\b(?:later|tomorrow|after|eventually|someday|not yet)\b", actions))
    pause = bool(re.search(
        r"\b(?:not (?:quite |really |yet )?ready|not yet|not now|no thanks|rather not|"
        r"stay (?:here|put|back|at the gate)|staying here|"
        r"(?:let's|lets) not (?:go|leave|move|depart|start|continue)|"
        r"(?:don't|do not|won't|will not|cannot|can't) (?:want to )?(?:go|leave|move|depart|start|continue|proceed))\b", actions
    )) or any(re.match(r"^(?:stop|pause|wait|hold on)\b", clause) or clause == "no" for clause in clauses)
    route_names = {"bridge": r"(?:signal )?bridge", "stairs": r"(?:sea )?(?:stairs|stairway)"}
    rejected = set()
    for name, pattern in route_names.items():
        for clause in clauses:
            if re.search(r"\b(?:not|don't|do not|won't|will not|never|no|avoid|rather than|instead of)\b[^.!?;,]{0,45}\b" + pattern + r"\b", clause):
                rejected.add(name)

    selected = []
    ambiguous_route = False
    ready = False
    if not question and not uncertain:
        for line, route in zip(ROUTE_LINES, ("bridge", "stairs", "bridge", "stairs")):
            if words == _words(line):
                selected.append(route)
        for clause in clauses:
            match = re.match(
                r"^(?:(?:i|we)(?:'ll| will| would| would like to| want to|'d(?: like to| rather)?)?\s+|let's\s+|lets\s+)?"
                r"(?P<verb>take|choose|pick|use|prefer|go via|go by|switch to|go with|head for|head via)\s+"
                r"(?:the\s+)?(?P<route>(?:signal\s+)?bridge|(?:sea\s+)?stairs|stairway)\b", clause
            )
            if match:
                route = "bridge" if "bridge" in match["route"] else "stairs"
                selected.append(route)
                mentioned = {name for name, pattern in route_names.items() if re.search(r"\b" + pattern + r"\b", clause)}
                ambiguous_route = ambiguous_route or len(mentioned - rejected) > 1
                # Choosing/preferring is not permission to start walking.
                ready = ready or match["verb"] not in ("choose", "pick", "prefer")
            ready = ready or bool(re.match(r"^(?:i'm ready|i am ready|let's go|lets go|lead the way|let's do this|lets do this|ready as i'll ever be)\b", clause))
    choices = set(selected) - rejected
    route = next(iter(choices)) if len(choices) == 1 and not ambiguous_route else None
    # Conflicting affirmative route commands need clarification, not an
    # arbitrary first/last route selection or departure on the previous route.
    conflict = len(set(selected)) > 1 or ambiguous_route
    return {"route": route, "ready": bool(ready and not (pause or question or uncertain or deferred or conflict or (rejected and not route))),
            "pause": pause, "question": question, "uncertain": (uncertain and not switch_route) or deferred or conflict, "switch_route": switch_route,
            "rejected_routes": tuple(sorted(rejected))}


def preview(quest, text):
    """Tentative next state; commit only after successful response completion."""
    result = dict(quest)
    intent = player_intent(text)
    if not (intent["question"] or intent["uncertain"]) and result.get("route") in intent["rejected_routes"]:
        result["route"] = None
    if intent["switch_route"] and quest.get("route") in ("bridge", "stairs"):
        result["route"] = "stairs" if quest["route"] == "bridge" else "bridge"
    if intent["route"]:
        result["route"] = intent["route"]
    result["completed"] = min(3, quest["completed"] + 1)
    # Presets still form the authored three-turn path. A custom route choice
    # followed by explicit readiness may finish in two; do not ask twice.
    can_depart = result["completed"] >= 3 or (result["completed"] >= 2 and quest.get("route") is not None)
    result["phase"] = "depart" if can_depart and result["route"] and intent["ready"] else "talking"
    return result


def context(quest, text):
    candidate = preview(quest, text)
    return {"completed": quest["completed"], "route": candidate["route"],
            "next_action": "walk_and_relight" if candidate["phase"] == "depart" else "confirm_departure" if candidate["route"] else "choose_route"}


def safe_context(value):
    if not isinstance(value, dict):
        return {}
    count = value.get("completed")
    return {"completed": count if type(count) is int and 0 <= count <= 3 else 0,
            "route": value.get("route") if value.get("route") in ("bridge", "stairs") else None,
            "next_action": value.get("next_action") if value.get("next_action") in ("walk_and_relight", "confirm_departure", "choose_route") else "choose_route"}


def dialogue_goal(value, text):
    """Specify a conversational purpose, never a canned answer or game action."""
    game = safe_context(value)
    if not game:
        return "Answer the player's actual message."
    route = {"bridge": "signal bridge", "stairs": "sea stairs"}.get(game["route"])
    intent = player_intent(text)
    if intent["pause"]:
        return "The player asked to pause or stay. Respect that immediately: remain at the gate and do not ask them to choose or leave yet. Answer any accompanying direct or out-of-character question honestly; do not restart the quest. A selected route is only a plan, not permission to move."
    line = _words(text)
    if intent["question"]:
        if line == _words(SAMPLE_LINES[1]):
            focus = "Answer whether they must cross the bridge: it is optional, and they may take the sea stairs instead."
        elif line == _words(SAMPLE_LINES[3]):
            focus = "Respond to their question about the journey. You only know about wind, exposure and damp steps; do not invent accidents or imply things happened before."
        else:
            focus = "Answer the player's actual question or request directly in the selected tone, using only the known scene facts."
        return focus + " Asking is not agreement to travel. Do not start walking, assume a route change, or replace the answer with a readiness question."
    if intent["uncertain"]:
        return "The player's message is conditional, deferred, or ambiguous. Answer their actual concern in the selected tone without treating it as agreement to leave now. If the route is unclear, ask one brief clarification."
    if intent["rejected_routes"] and not intent["route"]:
        return "The player rejected a route. Respect the refusal in the selected tone, do not send them down that route, and do not start moving. If needed, ask what they would prefer instead."
    if route and game["next_action"] == "walk_and_relight":
        return f"Departure is agreed. In the selected tone, name the {route} and tell the player you will lead them now. Do not ask for readiness again or claim arrival."
    if route and game["next_action"] == "confirm_departure":
        return f"The player chose the {route}. Acknowledge it in the selected tone, then ask whether they are ready. Do not switch routes."
    focus = "Acknowledge their reaction to your beacon task in the selected tone; do not repeat the opening briefing or treat it as a new arrival."
    return focus + " Leave the route up to the player. One brief bridge-or-stairs choice is enough. A pause, refusal, direct question or out-of-character request takes priority over this plan."


def note(quest):
    if quest["phase"] == "depart":
        return "Mara will lead the way after this reply. The journey starts in a moment."
    return "Mara’s response is generated live from your words and emotion estimate."


def signal(quest, session_id):
    return f'<div id="quest-signal" data-session="{html.escape(str(session_id), quote=True)}" data-count="{quest["completed"]}" data-route="{quest.get("route") or ""}" data-phase="{quest["phase"]}"></div>'
