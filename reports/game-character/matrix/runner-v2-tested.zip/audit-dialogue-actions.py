"""Audit saved custom-case actions against separately authored expectations.

This reads transcripts; it performs no inference and never judges dialogue prose.
"""
import argparse
import json
from pathlib import Path


def expected_after(item):
    slug = item["id"].split("/")[2]
    before = item["game_before"]
    route = before["route"]
    phase = "talking"
    if slug in ("bridge", "stairs"):
        route = slug
        if before["completed"] >= 2 or (before["completed"] >= 1 and before["route"]):
            phase = "depart"
    elif slug in ("change", "exclude_bridge"):
        route = "stairs"  # Preference selection; permission to leave is separate.
    elif slug in ("negated_bridge", "curly_negation", "will_not") and route == "bridge":
        route = None
    elif slug == "other_route" and route:
        route = "stairs" if route == "bridge" else "bridge"
    elif slug == "dont_worry" and before["route"] and before["completed"] >= 1:
        phase = "depart"
    return {"completed": min(3, before["completed"] + 1), "route": route, "phase": phase}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("responses", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    rows = [json.loads(line) for line in args.responses.read_text(encoding="utf-8").splitlines()]
    checks = [{"id": row["id"], "text": row["text"], "expected": expected_after(row),
               "actual": row["game_after"]} for row in rows if row["section"] == "customs"]
    result = {"scope": "Separately authored action expectations for the fixed 33 custom texts at four stages and seven cues. No semantic rating of generated text.",
              "checked": len(checks), "unique_text_stage_pairs": len({row["id"].rsplit("/", 1)[0] for row in checks}),
              "failures": [row for row in checks if row["expected"] != row["actual"]]}
    result["failed"] = len(result["failures"])
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in result.items() if key != "failures"}))


if __name__ == "__main__":
    main()
